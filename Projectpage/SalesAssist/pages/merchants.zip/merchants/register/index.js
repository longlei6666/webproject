// pages/merchants/register/index.js
const shopData = require('../../../utils/shopData.js')
Component({
    /**
     * 组件的属性列表
     */
    properties: {

    },

    /**
     * 组件的初始数据
     */
    data: {
        shopData: shopData.shopData,
        rateList:['0.025%','0.038%','0.046%','0.055%'],
        shopInput: {},
        showModal: false,
        date: shopData.shopData.shoplabel
    },

    /**
     * 组件的方法列表
     */
    methods: {
        /* 文本框获取焦点时更改状态*/
        focus: function(e) {
            var cur = e.target.dataset.current;
            this.setData({
                status: cur
            })
        },
        /* 文本框失去焦点时更改状态*/
        blur: function(e) {
            var data = e.detail.value
            var cur = e.target.dataset.current;
            if (!data) {
                this.setData({
                    status: '',
                })
            } else {
                var shopInput = this.data.shopInput
                shopInput[cur] = data
                this.setData({
                    status1: cur,
                    shopInput: shopInput
                })
            }
        },
        bindDateChange(e) {
            var data = e.detail.value
            var cur = e.target.dataset.current;
            if (!data) {
                this.setData({
                    status: '',
                })
            } else {
                var shopInput = this.data.shopInput
                shopInput[cur] = data
                this.setData({
                    status1: cur,
                    date: e.detail.value,
                    shopInput: shopInput
                })
            }
        },
        bindPickerChange(e) {
            var data = e.detail.value
            var cur = e.target.dataset.current;
            if (!data) {
                this.setData({
                    status: '',
                })
            } else {
                var shopInput = this.data.shopInput
                shopInput[cur] = this.data.rateList[data]
                this.setData({
                    status1: cur,
                    index: e.detail.value,
                    shopInput: shopInput
                })
            }
        },
        bindBankchoose(e) {
            var cur = e.target.dataset.current;
            this.setData({
                showModal: true
            })
        },
        //弹出框蒙层截断touchmove事件
        preventTouchMove(e) { },
        //隐藏模态对话框
        hideModal: function (e) {
            this.setData({
                showModal: false
            });
        },
        //对话框取消按钮点击事件
        onCancel(e) {
            this.hideModal();
        },
        //对话框确认按钮点击事件
        onConfirm(e) {
            this.hideModal();
            wx.showToast({
                title: '修改成功',
            })
        }
    },
})
var FYRateD0 = [{
		value: 'MA054',
		text: '0.02%,另加收1元/笔'
}, {
		value: 'M0008',
		text: '0.5%，8元封顶;另加收1元/笔'
	}]	
var FYRate = [{
	value: 'Z0323',
	text: '0.23%,无封顶'
}, {
	value: 'M0196',
	text: '0.25%,无封顶'
},  {
	value: 'M2002',
	text: '0.31%,无封顶'
}, {
	value: 'M0261',
	text: '0.33%,无封顶'
}, {
	value: 'M0325',
	text: '0.38%,无封顶'
}, {
	value: 'M0355',
	text: '0.46%,无封顶'
},{
	value: 'M2008',
	text: '0.51%,无封顶'
}, {
	value: 'Z0203',
	text: '0.59%,无封顶'
}, {
	value: 'M0027',
	text: '0.60%,无封顶'
}]
var headbankData = [{
	value: 'BOC',
	text: '中国银行',
}, {
	value: 'ABC',
	text: '中国农业银行',
}, {
	value: 'CCB',
	text: '中国建设银行',
}, {
	value: 'BOC',
	text: '中国银行',
}, {
	value: 'ECITIC',
	text: '中信银行',
}]